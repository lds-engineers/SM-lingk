 <?php

require_once '../../../config.php';
global $DB,$CFG;

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');



   $limit=$_REQUEST['limit'];
   $offset=$_REQUEST['offset'];
   $table=$_REQUEST['table'];

    $prefix= $CFG->prefix;
if(substr($table, 0, strlen($prefix)) == $prefix) {
    $table1 = substr($table, strlen($prefix));
    
} 
else{
 $table1=$table;
}
$table_data=$prefix.$table1;
$getuser = $DB->get_records_sql("SELECT * FROM $table_data LIMIT $limit OFFSET $offset ");
      foreach($getuser as $row)
         {
           $data[]=$row;
         }
      
        $json_data=json_encode($data);
        echo $json_data;

?>