 <?php
require_once '../../../config.php';
global $DB,$CFG;
   
   $prefix= $CFG->prefix;

   $table=$_REQUEST['table'];
   $limit=$_REQUEST['limit'];
   $offset=$_REQUEST['offset'];

 if(substr($table, 0, strlen($prefix)) == $prefix) {
    $table1 = substr($table, strlen($prefix));
    
} 
else{
 $table1=$table;
}
 
   $bulkdata = $DB->get_records_sql("select * FROM  ".$prefix.$table1."  LIMIT $limit OFFSET $offset  ");
      foreach($bulkdata as $row)
         {
           $data[]=$row;
         }
      
        $json_data=json_encode($data);
        echo $json_data;

?>