 <?php
require_once '../../../config.php';
global $DB;

   $getplugin = $DB->get_records_sql("SELECT plugin,name,value FROM mdl_config_plugins WHERE plugin like '%local_moodle_api_plug%' LIMIT 0,1");
      foreach($getplugin as $row)
         {
           $data[]=$row;
         }
      
        $json_data=json_encode($data);
        echo $json_data;

?>